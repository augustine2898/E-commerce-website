const express = require('express');
const router = express.Router();
const User = require('../models/User'); // Import the User model
const bcrypt = require('bcrypt');

// Signup Route
router.get('/signup', (req, res) => res.render('signup'));

router.post('/signup', async (req, res) => {
  const { fullname, username, password, passwordConfirm} = req.body;

  if (password !== passwordConfirm) {
    return res.render('signup', { msg: 'Passwords do not match' });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ fullname,username, password: hashedPassword, isAdmin: false });
    await user.save();
    res.redirect('/login');
  } catch (err) {
    console.error('Signup error:', err);
    res.render('signup', { msg: 'Error signing up. Please try again.' });
  }
});

// Login Route
router.get('/login', (req, res) => res.render('login'));
router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    // Check for a user in the database
    let user = await User.findOne({ username });
    if (user && await user.comparePassword(password)) {
      console.log(user)
      // User is valid
      
      req.session.userId = user._id;
      req.session.isAdmin = user.isAdmin;
      if (user.isAdmin) {
        return res.redirect('/admin/dashboard'); // Redirect to admin dashboard if admin
      } else {
        return res.redirect('/'); // Redirect to home page if regular user
      }
    } else {
      // If user not found or password incorrect
      return res.render('login', { msg: 'Invalid username or password' });
    }
  } catch (err) {
    console.error('Login error:', err);
    res.render('login', { msg: 'Error logging in. Please try again.' });
  }
});

// Logout Route
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

// Home Route
router.get('/', (req, res) => {
  if (!req.session.userId) return res.redirect('/login');
  res.render('home');
});

module.exports = router;
