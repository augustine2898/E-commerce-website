const express = require('express');
const adminrouter = express.Router();
const User = require('../models/User'); // Require the User model to interact with the database
const bcrypt = require('bcrypt');

// Admin Login Route
adminrouter.get('/login', (req, res) => {
  if(req.session.isAdmin){
  res.render('admin-dashboard'); }
  else{
    res.render('admin-login');// Render admin login form

  }
});

adminrouter.post('/login', async (req, res) => {
    console.log('Admin login route hit');
    const { username, password } = req.body;
    console.log('Admin login attempt:', { username, password });

    // Check if the username and password match the environment variables
    if (
        username === process.env.ADMIN_USERNAME &&
        password === process.env.ADMIN_PASSWORD
    ) {
        req.session.userId = 'admin'; // Assign a unique identifier for the admin
        req.session.isAdmin = true;
        console.log('Admin logged in successfully');
        return res.redirect('/admin/dashboard'); // Redirect to admin dashboard
    } else {
        console.log('Invalid credentials');
        return res.render('admin-login', { msg: 'Invalid credentials' });
    }
});

// Admin Dashboard Route
adminrouter.get('/dashboard', async (req, res) => {
    if (req.session.isAdmin) {
        try {
            const users = await User.find(); // Fetch all users from the database
            res.render('admin-dashboard', { users }); // Pass users to the template
        } catch (err) {
            console.error('Error fetching users:', err);
            res.redirect('/admin/login');
        }
    } else {
        res.redirect('/admin/login');
    }
});

// Display the user creation form
adminrouter.get('/create', (req, res) => {
    if (req.session.isAdmin) {
        res.render('create-user'); // Render the create-user form
    } else {
        res.redirect('/admin/login'); // Redirect to login if not an admin
    }
});

//Handle form submission for creating a new user
adminrouter.post('/create', async (req, res) => {
  const { username, password, passwordConfirm, email ,fullname} = req.body;
  console.log(password)
  // Check if passwords match
  if (password !== passwordConfirm) {
      return res.render('create-user', { msg: 'Passwords do not match' });
  }

  try {//const hashedPassword = await bcrypt.hash(password, 10)
      // Create a new user instance
      const user = new User({
          fullname,
          username,
          password, // Hash the password before saving
          email,
          isAdmin: false, // Set isAdmin to false by default
      });

      // Save the user to the database
      await user.save();
      console.log('User created successfully'); // Debugging line

      // Redirect to the admin dashboard after successful creation
      res.redirect('/admin/dashboard');
  } catch (err) {
      console.error('Create user error:', err);

      // Render the form with an error message if something goes wrong
      res.render('create-user', { msg: 'Error creating user. Please try again.' });
  }
});



// Route to display the edit form for a specific user
adminrouter.get('/edit/:id', async (req, res) => {
  // Check if the user is an admin; if not, redirect to login
  if (!req.session.isAdmin) return res.redirect('/admin/login');
  
  try {
    // Find the user by ID
    const user = await User.findById(req.params.id);
    if (!user) return res.redirect('/admin/dashboard');
    // Render the edit form with the user's current details
    res.render('admin-edit', { user });
  } catch (err) {
    console.error('Error fetching user for edit:', err);
    // Redirect to the dashboard if there's an error
    res.redirect('/admin/dashboard');
  }
});

// Route to handle form submission for updating user details
adminrouter.post('/edit/:id', async (req, res) => {
  // Check if the user is an admin; if not, redirect to login
  if (!req.session.isAdmin) return res.redirect('/admin/login');
  
  const { username, email, password, passwordConfirm ,fullname} = req.body;

  // Check if passwords match
  if (password && password !== passwordConfirm) {
    return res.render('admin-edit', { msg: 'Passwords do not match', user: req.body });
  }

  try {
    // Prepare the data to update
    const updateData = { username, email,fullname };
    if (password) updateData.password = await bcrypt.hash(password, 10); // Hash the new password if provided

    // Update the user in the database
    await User.findByIdAndUpdate(req.params.id, updateData);
    // Redirect to the admin dashboard after successful update
    res.redirect('/admin/dashboard');
  } catch (err) {
    console.error('Edit user error:', err);
    // Render the form with an error message if something goes wrong
    res.render('admin-edit', { msg: 'Error updating user. Please try again.', user: req.body });
  }
});


// Route to handle user deletion
adminrouter.post('/delete/:id', async (req, res) => {
  // Check if the user is an admin; if not, redirect to login
  if (!req.session.isAdmin) return res.redirect('/admin/login');
  
  try {
    // Delete the user by ID
    await User.findByIdAndDelete(req.params.id);
    // Redirect to the admin dashboard after successful deletion
    res.redirect('/admin/dashboard');
  } catch (err) {
    console.error('Delete user error:', err);
    // Redirect to the dashboard if there's an error
    res.redirect('/admin/dashboard');
  }
});
//serach 
adminrouter.get('/search', async (req, res) => {
  try {
    const query = req.query.query || ''; // Fetch the query parameter, or set it to an empty string
    console.log('Search Query:', query)
    let users;
    if (query) {
      // Perform search if there's a query
      users = await User.find({
        $or: [
          //{ fullname: { $regex: query, $options: 'i' } }, // Search in fullname
          { username: { $regex: query, $options: 'i' } }, // Search in username
          { email: { $regex: query, $options: 'i' } } // Search in email
        ]
      });
    } else {
      // If no query, return the whole list
      users = await User.find({});
    }
    console.log('Users Found:', users);
    // Render the admin dashboard with the users data
    res.render('admin-dashboard', { users, query }); // Pass the query back to keep it in the input field
  } catch (err) {
    console.error('Error fetching users:', err);
    res.render('admin-dashboard', { users: [], msg: 'Error fetching users. Please try again.' });
  }
});





// Admin Logout Route
adminrouter.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            console.error('Error destroying session:', err);
            return res.redirect('/admin/dashboard'); // Redirect to dashboard if there's an error
        }
        res.redirect('/admin/login'); // Redirect to admin login after successful logout
    });
});

module.exports = adminrouter;
